import * as vscode from 'vscode';
import { webcrypto } from 'node:crypto';
import * as https from 'node:https';

export function activate(context: vscode.ExtensionContext) {
    console.log('envdrop is now active!');

    // 1. SET TOKEN COMMAND
    let setToken = vscode.commands.registerCommand('envdrop.setToken', async () => {
        const token = await vscode.window.showInputBox({
            prompt: 'Enter your envdrop API Token (sk_ed_...)',
            placeHolder: 'Find this in your envdrop Dashboard > API & Tokens',
            ignoreFocusOut: true,
            password: true
        });

        if (token) {
            await context.secrets.store('envdrop.token', token);
            vscode.window.showInformationMessage('envdrop: API Token saved securely.');
        }
    });

    // 2. SHARE COMMAND (FILES OR SELECTION)
    let share = vscode.commands.registerCommand('envdrop.share', async (uri: vscode.Uri) => {
        const token = await context.secrets.get('envdrop.token');
        if (!token) {
            const action = 'Set Token';
            const res = await vscode.window.showErrorMessage('envdrop: No API Token found. Please set your token first.', action);
            if (res === action) vscode.commands.executeCommand('envdrop.setToken');
            return;
        }

        let content = '';
        let fileName = 'Untitled Secret';

        // Check if coming from Explorer right-click or Editor right-click
        if (uri && uri.fsPath) {
            const doc = await vscode.workspace.openTextDocument(uri);
            content = doc.getText();
            fileName = uri.fsPath.split(/[\\/]/).pop() || 'secret.env';
        } else {
            const editor = vscode.window.activeTextEditor;
            if (editor) {
                content = editor.document.getText(editor.selection) || editor.document.getText();
                fileName = editor.document.fileName.split(/[\\/]/).pop() || 'snippet.env';
            }
        }

        if (!content) {
            vscode.window.showWarningMessage('envdrop: No content to share.');
            return;
        }

        try {
            vscode.window.withProgress({
                location: vscode.ProgressLocation.Notification,
                title: "envdrop: Encrypting & Sharing...",
                cancellable: false
            }, async (progress) => {
                const { encrypted, key } = await encryptDataNode(content);
                
                const response: any = await callEnvdropApi({
                    encrypted,
                    label: fileName,
                    ttl: '24h',
                    token
                });

                if (response && response.id) {
                    const baseUrl = vscode.workspace.getConfiguration('envdrop').get('endpoint') || 'https://envdrop-uaru.vercel.app';
                    const finalUrl = `${baseUrl}/share/${response.id}#${key}`;
                    
                    await vscode.env.clipboard.writeText(finalUrl);
                    vscode.window.showInformationMessage(`envdrop: Secure link generated and copied to clipboard!`, 'Open Link').then(selection => {
                        if (selection === 'Open Link') {
                            vscode.env.openExternal(vscode.Uri.parse(finalUrl));
                        }
                    });
                } else {
                    throw new Error(response.error || 'Failed to generate link');
                }
            });
        } catch (err: any) {
            vscode.window.showErrorMessage(`envdrop Error: ${err.message}`);
        }
    });

    context.subscriptions.push(setToken, share);
}

// AES-256-GCM ENCRYPTION (NODE VERSION TO MATCH BROWSER)
async function encryptDataNode(text: string): Promise<{ encrypted: string; key: string }> {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    
    const key = await webcrypto.subtle.generateKey(
        { name: "AES-GCM", length: 256 },
        true,
        ["encrypt", "decrypt"]
    );
    
    const iv = webcrypto.getRandomValues(new Uint8Array(12));
    
    const encrypted = await webcrypto.subtle.encrypt(
        { name: "AES-GCM", iv },
        key,
        data
    );
    
    const exportedKey = await webcrypto.subtle.exportKey("raw", key);
    const combined = new Uint8Array(iv.length + encrypted.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(encrypted), iv.length);
    
    return {
        encrypted: Buffer.from(combined).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''),
        key: Buffer.from(exportedKey as ArrayBuffer).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
    };
}

// API CALL HELPER
function callEnvdropApi(payload: any): Promise<any> {
    const endpoint = vscode.workspace.getConfiguration('envdrop').get('endpoint') as string;
    const url = new URL('/api/share', endpoint);

    return new Promise((resolve, reject) => {
        const req = https.request(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': payload.token
            }
        }, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(body));
                } catch (e) {
                    reject(new Error('Invalid response from server'));
                }
            });
        });

        req.on('error', reject);
        req.write(JSON.stringify({
            encrypted: payload.encrypted,
            label: payload.label,
            ttl: payload.ttl
        }));
        req.end();
    });
}

export function deactivate() {}
