# envdrop VS Code Extension

Encrypt and share environment variables directly from VS Code with Zero-Knowledge security. ✨🔐

## Features

- **Right-Click Sharing**: Right-click any `.env` file in the Explorer and select "envdrop: Share Securely".
- **Selection Support**: Highlight a specific part of a file and share only that selection.
- **Zero-Knowledge**: All encryption happens locally in your editor using AES-256-GCM.
- **Auto-Clipboard**: The secure link (including the decryption fragment) is automatically copied to your clipboard.

## Setup

1. **Get your API Token**: In your **envdrop Dashboard**, go to the **API & Tokens** tab and generate a new key.
2. **Set Token in VS Code**:
   - Open Command Palette (`Cmd+Shift+P` / `Ctrl+Shift+P`).
   - Type `envdrop: Set API Token`.
   - Paste your `sk_ed_...` token.

## How to Test Locally

1. Open this `envdrop-extension` folder in a new VS Code window.
2. Run `npm install` in the terminal.
3. Press **F5** to open the **Extension Development Host**.
4. In the new window, open any project, right-click a `.env` file, and share it!

## Security

envdrop uses industry-standard AES-256-GCM encryption. We never see your raw secrets. Your decryption key is stored only in the URL fragment (`#`) which never leaves your browser.
